#include "types.h"
#include "stat.h"
#include "user.h"
#include "syscall.h"

#define PGSIZE 4096


void dump2() {

  /* Fork a new process to play with */
  /* We don't have a good way to list all pids in the system
     so forking a new process works for testing */ 
  int pid = fork();
  

  if (pid == 0) {
  
  	void* n = sbrk(16);
  	int x = 0x00000400;
  	memset(n, 0, 16);
  	memmove(n, &x, sizeof(int));

    /* child spins and yields */
    while (1) {
       sleep(5);
    };
  }
  


  /* parent dumps memory of the child */
  
  //dump(int pid, void *addr, void *buffer, int size)
  sleep(20);
	void* m = malloc(PGSIZE*10);
	memset(m, 0, PGSIZE*10);
	
	
	// The following addr and size may be changed manually during testing
	void* addr = (char*)96;
	int size = 1024;

	if (dump(pid, addr, m, size) != 0) {
		exit();		
	}
	
	printf(1, "%s%d%s%x%s%d%s\n","pid = ", pid, "   addr = 0x", addr, "   size = ", size, " bytes");
	
	if (size % 4 != 0)
		printf(1, "%s\n", "Warning: size isn't multiple of 4,  memory dumped shall be cut off!");
	
	int i = (int)addr;
	printf(1, "%s\n", "Address     column1      column2      column3      column4");
	
	for (; i < size;){
		printf(1, "%s%x%s", "0x", i, ": ");
		if (i < size)
			printf(1, "%s%x%s", "0x", *(int*)(m+i), "   ");
		i += 4;
		if (i < size)
			printf(1, "%s%x%s", "0x", *(int*)(m+i+4), "   ");
		i += 4;
		if (i < size)
			printf(1, "%s%x%s", "0x", *(int*)(m+i+8), "   ");
		i += 4;
		if (i < size)
			printf(1, "%s%x%s\n", "0x", *(int*)(m+i+12), "   ");
		i += 4;		
	}
	printf(1, "\n%s\n", "specified memory has been dumped");
	  
}

int main(int argc, char *argv[])
{
	dump2();
	exit();
}
