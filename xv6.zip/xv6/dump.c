#include "types.h"
#include "stat.h"
#include "user.h"
#include "syscall.h"

#define PGSIZE 4096


void dump2() {

  /* Fork a new process to play with */
  /* We don't have a good way to list all pids in the system
     so forking a new process works for testing */ 
  int pid = fork();
  

  if (pid == 0) {
  
  	void* n = sbrk(16);
  	int x = 0x00000400;
  	memset(n, 0, 16);
  	memmove(n, &x, sizeof(int));

    /* child spins and yields */
    while (1) {
       sleep(5);
    };
  }
  


  /* parent dumps memory of the child */
  
  //dump(int pid, void *addr, void *buffer, int size)
  sleep(20);
	void* m = malloc(PGSIZE*10);
	memset(m, 0, PGSIZE*10);
	
	void* addr = 0;
	int size = 3 * PGSIZE + 16;

	if (dump(pid, addr, m, size) != 0) {
		exit();		
	}
	
	int i = (int)addr;
	cprintf("%x\n", size);
	for (; i < size; i += 16){
		printf(1, "%s%d%s%x", " i = ", i, " ", *(int*)(m+i));
		printf(1, "%s%d%s%x", " i = ", i+4, " ", *(int*)(m+i+4));
		printf(1, "%s%d%s%x", " i = ", i+8, " ", *(int*)(m+i+8));
		printf(1, "%s%d%s%x\n", " i = ", i+12, " ", *(int*)(m+i+12));
		
	}
	  
}

int main(int argc, char *argv[])
{
	dump2();
	exit();
}
