#include "types.h"
#include "stat.h"
#include "user.h"
#include "syscall.h"

enum procstate { UNUSED, EMBRYO, SLEEPING, RUNNABLE, RUNNING, ZOMBIE };

struct uproc {
	uint sz;
	enum procstate state;
	int pid;
	int parent_id;
	int chan;
	int killed;
	char name[16];
};


int main(int argc, char *argv[])
{
	int pid = atoi(argv[1]);
	printf(1, "%s%d\n", "input pid = ", pid);
	struct uproc p;
	struct uproc* up = &p;
	if (getprocinfo(pid, up) == 0) {
		void* m = malloc(up->sz + 64);
		void* addr = 0x0;
		int size = up->sz;
		printf(1, "%s%x\n", "size = ", size);
		dump(pid, 0, m, up->sz);
		
			printf(1, "%s%d%s%x%s%d%s\n","pid = ", pid, "   addr = 0x", addr, "   size = ", size, " bytes");
	
	if (size % 4 != 0)
		printf(1, "%s\n", "Warning: size isn't multiple of 4,  memory dumped shall be cut off!");
	
	int i = (int)addr;
	printf(1, "%s\n", "Address     column1      column2      column3      column4");
	
	for (; i < size;){
		printf(1, "%s%x%s", "0x", i, ": ");
		if (i < size)
			printf(1, "%s%x%s", "0x", *(int*)(m+i), "   ");
		i += 4;
		if (i < size)
			printf(1, "%s%x%s", "0x", *(int*)(m+i+4), "   ");
		i += 4;
		if (i < size)
			printf(1, "%s%x%s", "0x", *(int*)(m+i+8), "   ");
		i += 4;
		if (i < size)
			printf(1, "%s%x%s\n", "0x", *(int*)(m+i+12), "   ");
		i += 4;		
	}
	printf(1, "\n%s\n", "specified memory has been dumped");
		
		
		
		
		
	} else {
		printf(1, "%s\n", "specified pid doesn't exist");
	}
	exit();
}
