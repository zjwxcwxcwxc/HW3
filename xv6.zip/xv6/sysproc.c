#include "types.h"
#include "x86.h"
#include "defs.h"
#include "date.h"
#include "param.h"
#include "memlayout.h"
#include "mmu.h"
#include "proc.h"

int
sys_fork(void)
{
  return fork();
}

int
sys_exit(void)
{
  exit();
  return 0;  // not reached
}

int
sys_wait(void)
{
  return wait();
}

int
sys_kill(void)
{
  int pid;

  if(argint(0, &pid) < 0)
    return -1;
  return kill(pid);
}

int
sys_getpid(void)
{
  return proc->pid;
}

int
sys_sbrk(void)
{
  int addr;
  int n;

  if(argint(0, &n) < 0)
    return -1;
  addr = proc->sz;
  if(growproc(n) < 0)
    return -1;
  return addr;
}

int
sys_sleep(void)
{
  int n;
  uint ticks0;

  if(argint(0, &n) < 0)
    return -1;
  acquire(&tickslock);
  ticks0 = ticks;
  while(ticks - ticks0 < n){
    if(proc->killed){
      release(&tickslock);
      return -1;
    }
    sleep(&ticks, &tickslock);
  }
  release(&tickslock);
  return 0;
}

// return how many clock tick interrupts have occurred
// since start.
int
sys_uptime(void)
{
  uint xticks;

  acquire(&tickslock);
  xticks = ticks;
  release(&tickslock);
  return xticks;
}


// return the memory layout for the process with pid,
// addr is where to begin dumping, buffer is where to
// copy memory to and size is # of bytes copied
int
sys_dump(void)
{
	//cprintf("%s\n", "sys_dump() in sysproc.c");
	int pid;
	char *addr;
	char *buffer;
	int size;
	
	if (argint(0, &pid) < 0)
		cprintf("%s\n", "argint(pid) error");
	if (argint(3, &size) < 0)
		cprintf("%s\n", "argint(size) error");
	if (argptr(2, &buffer, 4) < 0)
		cprintf("%s\n", "argptr(buffer) error");
	if (argptr(1, &addr, 4) < 0)
		cprintf("%s\n", "argptr(addr) error");
		
	//cprintf("%d\n", pid);
	//cprintf("%d\n", addr);
	//cprintf("%d\n", buffer);
	//cprintf("%d\n", size);
	
	if (dump(pid, addr, buffer, size) == 0)
		return 0;
	else return -1;
}


int
sys_getprocinfo(void)
{
	int pid;
	char* up;

	
	if (argint(0, &pid) < 0)
		cprintf("%s\n", "argint(pid) error");
	if (argptr(1, &up, 4) < 0)
		cprintf("%s\n", "argptr(up) error");
		
	//cprintf("%s%d\n", "sys_getprocinfo, pid = ", pid);
		
	if (getprocinfo(pid, (struct uproc*)up) == 0) {
		//cprintf("%s%d\n", "in sys_, up->pid = ", ((struct uproc*)up)->pid);
		return 0;
	}
	else return -1;

}
